function getDB() {
    const mongo = require('mongodb');
    const client = new mongo.MongoClient('mongodb://localhost:27017', { // connect to mongodb
        useNewUrlParser: true
    });
}

module.exports = getDB;